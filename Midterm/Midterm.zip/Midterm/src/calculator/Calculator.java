package calculator;
import javax.swing.JFrame;

public class Calculator extends  JFrame {

	private Double firstTerm;
	private Double secondTerm;
	
	public Calculator() {
		
	}
	
	public static void main(String[] args) {
		JFrame calculator = new Calculator();
	}
}
