package PartIV;

import javax.swing.JFrame;

public class RollDice extends JFrame {

	
	public RollDice() {
	}

	public static void main(String[] args) {
		RollDice rollDice = new RollDice();
	
	}
}
