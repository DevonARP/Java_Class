
public class WordReverser {

	public static String reverseSentence(String sentence) {
		return null;
	}
	
	public static void main(String[] args) {
		String result = reverseSentence("The quick brown fox jumps over the lazy dog");

	}

}
