
public class Trapezoid {
	
}
