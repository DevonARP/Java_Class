public class ComplexNumber {

        
        public static void main(String[] args) {
                Double testNan1 = new Double(5/0);
                Double testNan = new Double(5) / new Double(0);
                System.out.println(testNan);
                System.out.println(5.0/0);
                return;
        }

}
